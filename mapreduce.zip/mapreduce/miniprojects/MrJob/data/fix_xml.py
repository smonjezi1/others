from __future__ import unicode_literals
import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os
import lxml.etree as etree
import lxml.html

import unittest
import mwparserfromhell
from mwparserfromhell import parser
from mwparserfromhell.compat import range
from mwparserfromhell.nodes import Tag, Template, Text, Wikilink
from mwparserfromhell.nodes.extras import Parameter

for i in range(0,27):
    text_file = open('./fixed_part-000'+str("{0:0=2d}".format(i))+".xml", "w")#, encoding='utf-8')
    with open('./part-000'+str("{0:0=2d}".format(i))+'.xml',encoding='utf-8') as xml_file:
#    with open('./part-000'+str("{0:0=2d}".format(i))+'.xml') as xml_file:
#        text_file.write('<ROOT>\n'+str(xml_file.read())+'\n</ROOT>')
        text_file.write('<ROOT>\n'+repr(xml_file.read().encode('utf-8'))+'\n</ROOT>')
        text_file.close()