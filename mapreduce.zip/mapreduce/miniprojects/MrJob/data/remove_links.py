import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os



text_file = open("text_all_no_link.txt", "w", encoding='utf-8')
my_RE1= re.compile(r'(http://.+?)|(https://.+?)|(http\&\#58\;//.+?)|(Http&#58;//.+?)|(Http://.+?)')
my_RE2= re.compile(r'([^ ]*http[^ ]*)|([^ ]*\.com\/[^ ]*)|([^ ]*www\.[^ ]*)')
f=open('text_all.txt','r', encoding='utf-8')
for line in f.readlines():
    line=re.sub(my_RE1,' ',line)
    line=re.sub(my_RE2,' ',line)
    text_file.write(line+' ')
text_file.close()
f.close()

"""
worked
fd=open('part-00000.xml', encoding='utf-8')
soup = BeautifulSoup(fd, "lxml")
soup_texts=soup.select('text')
for i in soup_texts:
    print(i)
"""

"""
#root = etree.parse(r'./MrJob/data/part-00000.xml.bz2')
et = lxml.etree.fromstring('''<item><img src="cat.jpg" /> Picture of a cat</item>''')
et.find('img').tail
for i in range(1):
    root = etree.parse(r'./part-000'+str("{0:0=2d}".format(i))+'.xml')
    print(et.find('img').tail)
"""
