import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re

text_file = open("text_all.txt", "w", encoding='utf-8')
for i in range(27):
    fd=open(r'./part-000'+str("{0:0=2d}".format(i))+'.xml', encoding='utf-8')
    soup = BeautifulSoup(fd, "lxml")
    soup_texts=soup.select('text')
    for text in soup_texts:
        if text !='':
            text=re.sub('\n|\r|\t',' ',text.text)
            text_file.write(text+' ')
text_file.close()


"""
worked
fd=open('part-00000.xml', encoding='utf-8')
soup = BeautifulSoup(fd, "lxml")
soup_texts=soup.select('text')
for i in soup_texts:
    print(i)
"""

"""
#root = etree.parse(r'./MrJob/data/part-00000.xml.bz2')
et = lxml.etree.fromstring('''<item><img src="cat.jpg" /> Picture of a cat</item>''')
et.find('img').tail
for i in range(1):
    root = etree.parse(r'./part-000'+str("{0:0=2d}".format(i))+'.xml')
    print(et.find('img').tail)
"""
