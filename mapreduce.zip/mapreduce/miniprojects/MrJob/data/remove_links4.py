from __future__ import unicode_literals
import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os
import lxml.etree as etree
import lxml.html

import unittest
import mwparserfromhell
from mwparserfromhell import parser
from mwparserfromhell.compat import range
from mwparserfromhell.nodes import Tag, Template, Text, Wikilink
from mwparserfromhell.nodes.extras import Parameter

#my_RE1= re.compile(r'(http://.+?)|(https://.+?)|(http\&\#58\;//.+?)|(Http&#58;//.+?)|(Http://.+?)')
#my_RE2= re.compile(r'([^ ]*http[^ ]*)|([^ ]*\.com\/[^ ]*)|([^ ]*www\.[^ ]*)')

text_file = open("text_all_no_link.txt", "w")#, encoding='utf-8')
for i in range(27):
    fd=open(r'./part-000'+str("{0:0=2d}".format(i))+'.xml')#, encoding='utf-8')
#    soup = BeautifulSoup(str(fd.read()), "lxml")
    soup = BeautifulSoup(fd, "lxml")
    soup_texts=soup.select('text')    
    for text in soup_texts:
#        wikicode = mwparserfromhell.parse(text.text)
#        bigString = wikicode.filter_wikilinks(' ')
#        wikicode = mwparserfromhell.parse(text.text)
#        wikicode = mwparserfromhell.parse(text.text.encode('utf-8'))
        wikicode = mwparserfromhell.parse(text.text)
        bigString = wikicode.strip_code(normalize=True, collapse=True)
        bigString=re.sub('\n|\r|\t',' ',bigString)
#        bigString=re.sub('\'s ',' ',bigString)
#        bigString=re.sub(my_RE1,' ',bigString)
#        bigString=re.sub(my_RE2,' ',bigString)
        text_file.write(bigString+' ')
#        text_file.write(bigString+'\n')
#    print(bigString)
text_file.close()
fd.close()