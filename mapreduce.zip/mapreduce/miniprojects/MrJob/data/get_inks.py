from __future__ import unicode_literals
import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os
import lxml.etree as etree
import lxml.html

import unittest
import mwparserfromhell
from mwparserfromhell import parser
from mwparserfromhell.compat import range
from mwparserfromhell.nodes import Tag, Template, Text, Wikilink
from mwparserfromhell.nodes.extras import Parameter

#my_RE1= re.compile(r'(http://.+?)|(https://.+?)|(http\&\#58\;//.+?)|(Http&#58;//.+?)|(Http://.+?)')
#my_RE2= re.compile(r'([^ ]*http[^ ]*)|([^ ]*\.com\/[^ ]*)|([^ ]*www\.[^ ]*)')
my_RE3= re.compile(r'\[\[.+?\]\]|\[.+?\]')

text_file = open("link_stat.txt", "w",encoding='utf-8')#, encoding='utf-8')
s=0
for i in range(27):
#    fd=open(r'./part-000'+str("{0:0=2d}".format(i))+'.xml')#, encoding='utf-8')
    textlist=[]
    s=0
    with open(r'./fixed_part-000'+str("{0:0=2d}".format(i))+'.xml') as xml_file:
        root = etree.fromstring(xml_file.read())
        nodelist = root.findall('.//text')
        for node in nodelist:
            if node.text:
                s+=1
                wikicode = mwparserfromhell.parse(node.text)
                links = wikicode.filter_wikilinks()
                links = list(set(str(links)))
                text_file.write(str(s)+' '+str(len(links))+'\n')
    #            for link in links:
    #                text_file.write(str(s)+' '+str(len(links)))
text_file.close()

