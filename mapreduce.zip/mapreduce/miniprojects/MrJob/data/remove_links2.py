from __future__ import unicode_literals
import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os


import unittest
import mwparserfromhell
from mwparserfromhell import parser
from mwparserfromhell.compat import range
from mwparserfromhell.nodes import Tag, Template, Text, Wikilink
from mwparserfromhell.nodes.extras import Parameter


text_file = open("text_all_no_link.txt", "w", encoding='utf-8')
#my_RE1= re.compile(r'(http://.+?)|(https://.+?)|(http\&\#58\;//.+?)|(Http&#58;//.+?)|(Http://.+?)')
#my_RE2= re.compile(r'([^ ]*http[^ ]*)|([^ ]*\.com\/[^ ]*)|([^ ]*www\.[^ ]*)')
f=open('text_all.txt','r', encoding='utf-8')
wikicode = mwparserfromhell.parse(f)
bigString = wikicode.strip_code()
text_file.write(bigString)
#for line in bigString.readlines():
#    line=re.sub(my_RE1,' ',line)
#    line=re.sub(my_RE2,' ',line)
#    text_file.write(line+' ')
text_file.close()
f.close()