from __future__ import unicode_literals
import lxml
from lxml import etree
from bs4 import BeautifulSoup
import re
import os
import lxml.etree as etree
import lxml.html

import unittest
import mwparserfromhell
from mwparserfromhell import parser
from mwparserfromhell.compat import range
from mwparserfromhell.nodes import Tag, Template, Text, Wikilink
from mwparserfromhell.nodes.extras import Parameter

#my_RE1= re.compile(r'(http://.+?)|(https://.+?)|(http\&\#58\;//.+?)|(Http&#58;//.+?)|(Http://.+?)')
#my_RE2= re.compile(r'([^ ]*http[^ ]*)|([^ ]*\.com\/[^ ]*)|([^ ]*www\.[^ ]*)')
my_RE3= re.compile(r'\[\[.+?\]\]|\[.+?\]')

text_file = open("text_all_no_link.txt", "w",encoding='utf-8')#, encoding='utf-8')
for i in range(27):
#    fd=open(r'./part-000'+str("{0:0=2d}".format(i))+'.xml')#, encoding='utf-8')
    textlist=[]
    with open(r'./fixed_part-000'+str("{0:0=2d}".format(i))+'.xml') as xml_file:
           root = etree.fromstring(xml_file.read())
           nodelist = root.findall('.//text')
           for node in nodelist:
               textlist.append(node.text)
           for text in textlist:
               if text:
                    wikicode = mwparserfromhell.parse(text)
                    bigString = wikicode.strip_code(normalize=True, collapse=True)
                    text_file.write(bigString+' ')
text_file.close()
