A simple Spark Streaming with online learning example, based off of the streaming_twitter_cl example.  Run with
```bash
spark-submit twitter-streaming.py secrets_file.json 2> /dev/null
```
