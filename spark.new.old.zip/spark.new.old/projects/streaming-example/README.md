#### To run StreamingExample.scala:

```bash
sbt assembly && spark-submit target/scala-*/streaming-example*.jar
```
